//Código para menú
  function toggleMenu() {
    const menu = document.getElementById('dropdownMenu');
    menu.classList.toggle('active');
  }


//CÓDIGO PARA LA PÁGINA QUE TRABAJARÁ CON LA API
document.getElementById('buscar').addEventListener('click', () => {
    const nombre = document.getElementById('codigo').value.trim();
    if (!nombre) {
        document.getElementById('error').textContent = "Por favor, ingresa el nombre del medicamento.";
        return;
    }
 
    // Limpiar posibles errores
    document.getElementById('error').textContent = "";
 
    // URL con el parámetro de búsqueda
    const url = `https://cima.aemps.es/cima/rest/medicamentos?nombre=${encodeURIComponent(nombre)}`;
 
    // Realizar la solicitud a la API
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error al conectar con la API (Código: ${response.status})`);
            }
            return response.json(); // Parsear directamente a JSON
        })
        .then(data => {
            if (data.resultados && data.resultados.length > 0) {
                renderizarMedicamento(data.resultados[0]); // Renderizar el primer resultado
            } else {
                throw new Error("No se encontraron medicamentos con ese nombre.");
            }
        })
        .catch(err => {
            document.getElementById('error').textContent = err.message;
            limpiarCampos();
        });
});
 
// Función para renderizar el medicamento (sin cambios)
function renderizarMedicamento(medicamento) {
    document.getElementById('nombre').textContent = medicamento.nombre;
    /*document.getElementById('principios').textContent = medicamento.pactivos || "Información no disponible";*/
    document.getElementById('labtitular').textContent = medicamento.labtitular || "Información no disponible";
    document.getElementById('cpresc').textContent = medicamento.cpresc || "Información no disponible";
    document.getElementById('forma').textContent = medicamento.formaFarmaceutica?.nombre || "Información no disponible";
 
    // Vías de administración
    document.getElementById('vias').textContent =
        medicamento.viasAdministracion?.map(via => via.nombre).join(', ') || "Información no disponible";
 
    /*// Presentaciones
    const presentacionesUl = document.getElementById('presentaciones');
    presentacionesUl.innerHTML = ""; // Limpiar contenido anterior
    (medicamento.presentaciones || []).forEach(p => {
        const li = document.createElement('li');
        li.textContent = `${p.cn}: ${p.nombre}`;
        presentacionesUl.appendChild(li);
    });*/
 
    // Imágenes
    const imagenesDiv = document.getElementById('imagenes');
    imagenesDiv.innerHTML = ""; // Limpiar contenido anterior
    (medicamento.fotos || []).forEach(foto => {
        const img = document.createElement('img');
        img.src = foto.url;
        imagenesDiv.appendChild(img);
    });
 
   // Documentos
    const documentosUl = document.getElementById('documentos');
    documentosUl.innerHTML = ""; // Limpiar contenido anterior
    (medicamento.docs || []).forEach(doc => {
        const li = document.createElement('li');
        const a = document.createElement('a');
        a.href = doc.urlHtml;
        a.textContent = `Documento tipo ${doc.tipo}`;
        a.target = '_blank';
        li.appendChild(a);
        documentosUl.appendChild(li);
    });
}
 
// Función para limpiar campos
function limpiarCampos() {
    document.getElementById('nombre').textContent = "Nombre del Medicamento";
    document.getElementById('principios').textContent = "";
    document.getElementById('labtitular').textContent = "";
    document.getElementById('cpresc').textContent = "";
    document.getElementById('forma').textContent = "";
    document.getElementById('vias').textContent = "";
    document.getElementById('presentaciones').innerHTML = "";
    document.getElementById('imagenes').innerHTML = "";
    document.getElementById('documentos').innerHTML = "";
}


/*CÓDIGO PARA INGRESO DE USUARIO */
function validateLogin() {
    // Obtener los valores
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Checkeo de credenciales
    if (username === "Evelyn" && password === "1234") {
        // Dirigir a otra página
        window.location.href = "farmacos.html"; // URL deseada para dirigir
    } 
    else if (username === "Jonathan" && password === "5678") {
            // Dirigir a otra página
            window.location.href = "farmacos.html"; // URL deseada para dirigir
    }
     else {
        // Mostrar error
        document.getElementById("error").textContent = "Nombre de usuario o contraseña incorrectos. Intente nuevamente.";
    }
}


/*Código para el botón de ayuda*/
function showMessageAndRefresh() {
    alert("Tu solicitud ha sido enviada. Pronto estaremos enviando respuesta al correo ingresado"); // Display the message
    location.reload(); // Refresh the page
  }